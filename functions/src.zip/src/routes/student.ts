import { Router } from 'express';
import { StudentController } from '../controllers/StudentController';

const router = Router();
const studentController = new StudentController();

// 학생 생성
router.post('/', (req, res) => studentController.createStudent(req, res));

// 모든 학생 조회
router.get('/', (req, res) => studentController.getAllStudents(req, res));

// 학생 검색
router.get('/search', (req, res) => studentController.searchStudents(req, res));

// 학년별 학생 수 조회
router.get('/count/grade', (req, res) => studentController.getStudentCountByGrade(req, res));

// 활성 학생 수 조회
router.get('/count/active', (req, res) => studentController.getActiveStudentCount(req, res));

// 특정 학생 조회
router.get('/:id', (req, res) => studentController.getStudentById(req, res));

// 학생 정보 수정
router.put('/:id', (req, res) => studentController.updateStudent(req, res));

// 학생 삭제
router.delete('/:id', (req, res) => studentController.deleteStudent(req, res));

export { router as studentRoutes };
