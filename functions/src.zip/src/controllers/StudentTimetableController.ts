import { Request, Response } from 'express';
import { StudentTimetableService } from '../services/StudentTimetableService';
import type { CreateStudentTimetableRequest, UpdateStudentTimetableRequest, StudentTimetableSearchParams } from '@shared/types';

export class StudentTimetableController {
  private studentTimetableService: StudentTimetableService;

  constructor() {
    this.studentTimetableService = new StudentTimetableService();
  }

  // 학생 시간표 생성
  async createStudentTimetable(req: Request, res: Response): Promise<void> {
    try {
      const timetableData: CreateStudentTimetableRequest = req.body;
      const timetableId = await this.studentTimetableService.createStudentTimetable(timetableData);

      res.status(201).json({
        success: true,
        message: '학생 시간표가 성공적으로 생성되었습니다.',
        data: { id: timetableId }
      });
    } catch (error) {
      console.error('학생 시간표 생성 오류:', error);
      res.status(500).json({
        success: false,
        message: '학생 시간표 생성 중 오류가 발생했습니다.',
        error: error instanceof Error ? error.message : '알 수 없는 오류'
      });
    }
  }

  // 학생 시간표 조회 (ID로)
  async getStudentTimetableById(req: Request, res: Response): Promise<void> {
    try {
      const { id } = req.params;
      const timetable = await this.studentTimetableService.getStudentTimetableById(id);

      if (!timetable) {
        res.status(404).json({
          success: false,
          message: '학생 시간표를 찾을 수 없습니다.'
        });
        return;
      }

      res.json({
        success: true,
        data: timetable
      });
    } catch (error) {
      console.error('학생 시간표 조회 오류:', error);
      res.status(500).json({
        success: false,
        message: '학생 시간표 조회 중 오류가 발생했습니다.',
        error: error instanceof Error ? error.message : '알 수 없는 오류'
      });
    }
  }

  // 학생 ID로 시간표 조회
  async getStudentTimetableByStudentId(req: Request, res: Response): Promise<void> {
    try {
      const { studentId } = req.params;
      const timetable = await this.studentTimetableService.getStudentTimetableByStudentId(studentId);

      if (!timetable) {
        res.status(404).json({
          success: false,
          message: '해당 학생의 시간표를 찾을 수 없습니다.'
        });
        return;
      }

      res.json({
        success: true,
        data: timetable
      });
    } catch (error) {
      console.error('학생 ID로 시간표 조회 오류:', error);
      res.status(500).json({
        success: false,
        message: '학생 ID로 시간표 조회 중 오류가 발생했습니다.',
        error: error instanceof Error ? error.message : '알 수 없는 오류'
      });
    }
  }

  // 학생 시간표 수정
  async updateStudentTimetable(req: Request, res: Response): Promise<void> {
    try {
      const { id } = req.params;
      const updateData: UpdateStudentTimetableRequest = req.body;

      await this.studentTimetableService.updateStudentTimetable(id, updateData);

      res.json({
        success: true,
        message: '학생 시간표가 성공적으로 수정되었습니다.'
      });
    } catch (error) {
      console.error('학생 시간표 수정 오류:', error);
      res.status(500).json({
        success: false,
        message: '학생 시간표 수정 중 오류가 발생했습니다.',
        error: error instanceof Error ? error.message : '알 수 없는 오류'
      });
    }
  }

  // 학생 시간표 삭제
  async deleteStudentTimetable(req: Request, res: Response): Promise<void> {
    try {
      const { id } = req.params;
      await this.studentTimetableService.deleteStudentTimetable(id);

      res.json({
        success: true,
        message: '학생 시간표가 성공적으로 삭제되었습니다.'
      });
    } catch (error) {
      console.error('학생 시간표 삭제 오류:', error);
      res.status(500).json({
        success: false,
        message: '학생 시간표 삭제 중 오류가 발생했습니다.',
        error: error instanceof Error ? error.message : '알 수 없는 오류'
      });
    }
  }

  // 모든 학생 시간표 조회
  async getAllStudentTimetables(req: Request, res: Response): Promise<void> {
    try {
      const timetables = await this.studentTimetableService.getAllStudentTimetables();

      res.json({
        success: true,
        data: timetables,
        count: timetables.length
      });
    } catch (error) {
      console.error('학생 시간표 목록 조회 오류:', error);
      res.status(500).json({
        success: false,
        message: '학생 시간표 목록 조회 중 오류가 발생했습니다.',
        error: error instanceof Error ? error.message : '알 수 없는 오류'
      });
    }
  }

  // 학생 시간표 검색
  async searchStudentTimetables(req: Request, res: Response): Promise<void> {
    try {
      const searchParams: StudentTimetableSearchParams = req.query as any;
      const timetables = await this.studentTimetableService.searchStudentTimetables(searchParams);

      res.json({
        success: true,
        data: timetables,
        count: timetables.length
      });
    } catch (error) {
      console.error('학생 시간표 검색 오류:', error);
      res.status(500).json({
        success: false,
        message: '학생 시간표 검색 중 오류가 발생했습니다.',
        error: error instanceof Error ? error.message : '알 수 없는 오류'
      });
    }
  }

  // 학생 시간표 통계 조회
  async getStudentTimetableStatistics(req: Request, res: Response): Promise<void> {
    try {
      const statistics = await this.studentTimetableService.getStudentTimetableStatistics();

      res.json({
        success: true,
        data: statistics
      });
    } catch (error) {
      console.error('학생 시간표 통계 조회 오류:', error);
      res.status(500).json({
        success: false,
        message: '학생 시간표 통계 조회 중 오류가 발생했습니다.',
        error: error instanceof Error ? error.message : '알 수 없는 오류'
      });
    }
  }
}
