import * as functions from 'firebase-functions';
import * as admin from 'firebase-admin';
import express from 'express';
import cors from 'cors';
import { studentRoutes } from './routes/student';
import { parentRoutes } from './routes/parent';
import { studentSummaryRoutes } from './routes/student-summary';
import { attendanceRoutes } from './routes/attendance';
import { courseRoutes } from './routes/course';
import { classSectionRoutes } from './routes/class-section';

import { teacherRoutes } from './routes/teacher';
import { classroomRoutes } from './routes/classroom';

import { seatRoutes } from './routes/seat';
import { seatAssignmentRoutes } from './routes/seat-assignment';
// import testDataRoutes from './routes/test-data';

// Firebase Admin 초기화
admin.initializeApp();

// Express 앱 생성
const app = express();

// 미들웨어
app.use(cors({ origin: true }));
app.use(express.json());

// 기본 라우트
app.get('/', (req, res) => {
  res.json({ 
    message: 'WiseUp Management System API',
    version: '1.0.0',
    timestamp: new Date().toISOString()
  });
});

// 학생 관련 라우트
app.use('/api/students', studentRoutes);

// 부모 관련 라우트
app.use('/api/parents', parentRoutes);

// 학생 요약 정보 관련 라우트
app.use('/api/student-summaries', studentSummaryRoutes);

// 출석 기록 관련 라우트
app.use('/api/attendance', attendanceRoutes);

// 강의 관련 라우트
app.use('/api/courses', courseRoutes);

// 수업 관련 라우트
console.log('Registering class-sections routes...');
app.use('/api/class-sections', classSectionRoutes);
console.log('Class-sections routes registered successfully');



// 강사 관련 라우트
app.use('/api/teachers', teacherRoutes);

// 교실 관련 라우트
app.use('/api/classrooms', classroomRoutes);



// 좌석 관련 라우트
app.use('/api/seats', seatRoutes);

// 좌석 배정 관련 라우트
app.use('/api/seat-assignments', seatAssignmentRoutes);

// 테스트 데이터 초기화 관련 라우트 (임시 비활성화)
// app.use('/api/test-data', testDataRoutes);

// 라우트 등록 확인을 위한 디버깅
console.log('All routes registered. Available routes:');
app._router.stack.forEach((layer: any) => {
  if (layer.route) {
    console.log(`${layer.route.stack[0].method.toUpperCase()} ${layer.route.path}`);
  } else if (layer.name === 'router') {
    console.log(`Router: ${layer.regexp}`);
  }
});

// Firebase Functions로 export
export const api = functions.https.onRequest(app);
