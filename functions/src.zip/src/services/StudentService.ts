import * as admin from 'firebase-admin';
import { BaseService } from './BaseService';
import type { Student, CreateStudentRequest, UpdateStudentRequest, StudentSearchParams, Grade } from '@shared/types';

export class StudentService extends BaseService {
  constructor() {
    super('students');
  }

  // 학생 생성
  async createStudent(data: CreateStudentRequest): Promise<string> {
    const studentData: Omit<Student, 'id'> = {
      ...data,
      status: data.status || 'active',
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    };

    return this.create(studentData);
  }

  // 학생 조회 (ID로)
  async getStudentById(id: string): Promise<Student | null> {
    return this.getById<Student>(id);
  }

  // 학생 수정
  async updateStudent(id: string, data: UpdateStudentRequest): Promise<void> {
    const updateData = {
      ...data,
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    };

    await this.update(id, updateData);
  }

  // 학생 삭제
  async deleteStudent(id: string): Promise<void> {
    await this.delete(id);
  }

  // 모든 학생 조회
  async getAllStudents(): Promise<Student[]> {
    return this.getAll<Student>();
  }

  // 학생 검색
  async searchStudents(params: StudentSearchParams): Promise<Student[]> {
    let query: admin.firestore.Query = this.db.collection(this.collectionName);

    // 이름으로 검색
    if (params.name) {
      query = query.where('name', '>=', params.name)
                   .where('name', '<=', params.name + '\uf8ff');
    }

    // 학년으로 검색
    if (params.grade) {
      query = query.where('grade', '==', params.grade);
    }

    // 상태로 검색
    if (params.status) {
      query = query.where('status', '==', params.status);
    }

    // 부모 ID로 검색
    if (params.parentsId) {
      query = query.where('parentsId', '==', params.parentsId);
    }

    // 첫 등원일 범위로 검색
    if (params.firstAttendanceDateRange) {
      query = query.where('firstAttendanceDate', '>=', params.firstAttendanceDateRange.start)
                   .where('firstAttendanceDate', '<=', params.firstAttendanceDateRange.end);
    }

    // 마지막 등원일 범위로 검색
    if (params.lastAttendanceDateRange) {
      query = query.where('lastAttendanceDate', '>=', params.lastAttendanceDateRange.start)
                   .where('lastAttendanceDate', '<=', params.lastAttendanceDateRange.end);
    }

    return this.search<Student>(query);
  }

  // 학년별 학생 수 조회
  async getStudentCountByGrade(): Promise<Record<Grade, number>> {
    const students = await this.getAllStudents();
    
    if (students.length === 0) {
      return {} as Record<Grade, number>;
    }

    const countByGrade: Record<Grade, number> = {} as Record<Grade, number>;
    students.forEach(student => {
      countByGrade[student.grade] = (countByGrade[student.grade] || 0) + 1;
    });

    return countByGrade;
  }

  // 활성 학생 수 조회
  async getActiveStudentCount(): Promise<number> {
    const query = this.db.collection(this.collectionName)
                         .where('status', '==', 'active');
    
    const students = await this.search<Student>(query);
    return students.length;
  }

  // 첫 등원일 범위로 학생 조회
  async getStudentsByFirstAttendanceDate(startDate: admin.firestore.Timestamp, endDate: admin.firestore.Timestamp): Promise<Student[]> {
    const query = this.db.collection(this.collectionName)
                         .where('firstAttendanceDate', '>=', startDate)
                         .where('firstAttendanceDate', '<=', endDate);
    
    return this.search<Student>(query);
  }

  // 마지막 등원일 범위로 학생 조회
  async getStudentsByLastAttendanceDate(startDate: admin.firestore.Timestamp, endDate: admin.firestore.Timestamp): Promise<Student[]> {
    const query = this.db.collection(this.collectionName)
                         .where('lastAttendanceDate', '>=', startDate)
                         .where('lastAttendanceDate', '<=', endDate);
    
    return this.search<Student>(query);
  }
}
