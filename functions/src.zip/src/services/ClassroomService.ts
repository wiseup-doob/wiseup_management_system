import * as admin from 'firebase-admin';
import { BaseService } from './BaseService';
import type { 
  Classroom, 
  CreateClassroomRequest, 
  UpdateClassroomRequest, 
  ClassroomSearchParams 
} from '@shared/types';

export class ClassroomService extends BaseService {
  constructor() {
    super('classrooms');
  }

  // 교실 생성
  async createClassroom(data: CreateClassroomRequest): Promise<string> {
    const classroomData: Omit<Classroom, 'id'> = {
      name: data.name,
      capacity: data.capacity,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    };

    return this.create(classroomData);
  }

  // 교실 조회 (ID로)
  async getClassroomById(id: string): Promise<Classroom | null> {
    return this.getById<Classroom>(id);
  }

  // 교실 수정
  async updateClassroom(id: string, data: UpdateClassroomRequest): Promise<void> {
    const updateData = {
      ...data,
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    };

    await this.update(id, updateData);
  }

  // 교실 삭제
  async deleteClassroom(id: string): Promise<void> {
    await this.delete(id);
  }

  // 모든 교실 조회
  async getAllClassrooms(): Promise<Classroom[]> {
    return this.getAll<Classroom>();
  }

  // 교실 검색
  async searchClassrooms(params: ClassroomSearchParams): Promise<Classroom[]> {
    let query: admin.firestore.Query = this.db.collection(this.collectionName);

    // 교실명으로 검색
    if (params.name) {
      query = query.where('name', '>=', params.name)
                   .where('name', '<=', params.name + '\uf8ff');
    }

    return this.search<Classroom>(query);
  }

  // 교실 통계 조회
  async getClassroomStatistics(): Promise<{
    totalClassrooms: number;
    totalCapacity: number;
    averageCapacity: number;
  }> {
    const classrooms = await this.getAllClassrooms();
    
    if (classrooms.length === 0) {
      return {
        totalClassrooms: 0,
        totalCapacity: 0,
        averageCapacity: 0
      };
    }

    const totalCapacity = classrooms.reduce((sum, c) => sum + (c.capacity || 0), 0);
    const averageCapacity = totalCapacity / classrooms.length;

    return {
      totalClassrooms: classrooms.length,
      totalCapacity,
      averageCapacity: Math.round(averageCapacity)
    };
  }

  // 교실 정보 검증
  async validateClassroomData(classroomData: Partial<Classroom>): Promise<{
    isValid: boolean;
    issues: string[];
  }> {
    const issues: string[] = [];

    // 필수 필드 검증
    if (!classroomData.name || classroomData.name.trim().length === 0) {
      issues.push('교실명은 필수입니다.');
    }

    // 수용 인원 검증 (선택사항이지만 값이 있으면 0보다 커야 함)
    if (classroomData.capacity !== undefined && classroomData.capacity <= 0) {
      issues.push('수용 인원은 0보다 커야 합니다.');
    }

    return {
      isValid: issues.length === 0,
      issues
    };
  }
}
