import * as admin from 'firebase-admin';
import { BaseService } from './BaseService';
import type { 
  ClassSection, 
  CreateClassSectionRequest, 
  UpdateClassSectionRequest, 
  ClassSectionSearchParams,
  ClassScheduleBlock,
  ClassScheduleGrid,
  ClassScheduleSearchParams,
  DayOfWeek
} from '@shared/types';

export class ClassSectionService extends BaseService {
  constructor() {
    super('class_sections');
  }

  // 수업 생성
  async createClassSection(data: CreateClassSectionRequest): Promise<string> {
    // schedule 검증 로직 추가
    if (data.schedule && data.schedule.length > 0) {
      for (const schedule of data.schedule) {
        if (!schedule.dayOfWeek || !schedule.startTime || !schedule.endTime) {
          throw new Error('스케줄의 요일, 시작 시간, 종료 시간은 필수입니다.');
        }
        
        // 시간 형식 검증 (HH:MM)
        const timeRegex = /^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/;
        if (!timeRegex.test(schedule.startTime) || !timeRegex.test(schedule.endTime)) {
          throw new Error('시간 형식이 올바르지 않습니다. (HH:MM)');
        }
        
        // 시작 시간이 종료 시간보다 빠른지 검증
        if (schedule.startTime >= schedule.endTime) {
          throw new Error('시작 시간은 종료 시간보다 빨라야 합니다.');
        }
      }
    }

    const classSectionData: Omit<ClassSection, 'id'> = {
      ...data,
      currentStudents: data.currentStudents ?? 0,
      status: data.status ?? 'active',
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    };

    return this.create(classSectionData);
  }

  // 수업 조회 (ID로)
  async getClassSectionById(id: string): Promise<ClassSection | null> {
    return this.getById<ClassSection>(id);
  }

  // 수업 수정
  async updateClassSection(id: string, data: UpdateClassSectionRequest): Promise<void> {
    // schedule 검증 로직 추가 (수정 시에도 동일한 검증 적용)
    if (data.schedule && data.schedule.length > 0) {
      for (const schedule of data.schedule) {
        if (!schedule.dayOfWeek || !schedule.startTime || !schedule.endTime) {
          throw new Error('스케줄의 요일, 시작 시간, 종료 시간은 필수입니다.');
        }
        
        // 시간 형식 검증 (HH:MM)
        const timeRegex = /^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/;
        if (!timeRegex.test(schedule.startTime) || !timeRegex.test(schedule.endTime)) {
          throw new Error('시간 형식이 올바르지 않습니다. (HH:MM)');
        }
        
        // 시작 시간이 종료 시간보다 빠른지 검증
        if (schedule.startTime >= schedule.endTime) {
          throw new Error('시작 시간은 종료 시간보다 빨라야 합니다.');
        }
      }
    }

    const updateData = {
      ...data,
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    };

    await this.update(id, updateData);
  }

  // 수업 삭제
  async deleteClassSection(id: string): Promise<void> {
    await this.delete(id);
  }

  // Course와 ClassSection을 한번에 생성
  async createClassWithCourse(data: {
    courseName: string;
    subject: string;
    difficulty?: string;
    name: string;
    teacherId: string;
    classroomId: string;
    schedule: Array<{ dayOfWeek: DayOfWeek; startTime: string; endTime: string }>;
    maxStudents: number;
    description?: string;
    notes?: string;
  }): Promise<{ course: any; classSection: ClassSection }> {
    // 1단계: Course 찾기 또는 생성
    let courseId: string;
    let course: any;

    // 기존 Course가 있는지 확인 (이름, 과목, 난이도로)
    const existingCourse = await this.db
      .collection('courses')
      .where('name', '==', data.courseName)
      .where('subject', '==', data.subject)
      .where('difficulty', '==', data.difficulty)
      .limit(1)
      .get();

    if (!existingCourse.empty) {
      // 기존 Course 사용
      course = existingCourse.docs[0].data();
      courseId = existingCourse.docs[0].id;
      console.log('기존 Course 사용:', courseId);
    } else {
      // 새 Course 생성
      const newCourse = {
        name: data.courseName,
        subject: data.subject,
        difficulty: data.difficulty,
        description: data.description || '',
        isActive: true,
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
        updatedAt: admin.firestore.FieldValue.serverTimestamp()
      };

      const courseRef = await this.db.collection('courses').add(newCourse);
      courseId = courseRef.id;
      course = { id: courseId, ...newCourse };
      console.log('새 Course 생성:', courseId);
    }

    // 2단계: ClassSection 생성
    const classSectionData: Omit<ClassSection, 'id'> = {
      name: data.name,
      courseId,
      teacherId: data.teacherId,
      classroomId: data.classroomId,
      schedule: data.schedule,
      maxStudents: data.maxStudents,
      currentStudents: 0,
      description: data.description || '',
      notes: data.notes || '',
      status: 'active',
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    };

    const classSectionId = await this.create(classSectionData);
    const classSection = await this.getById<ClassSection>(classSectionId);

    if (!classSection) {
      throw new Error('ClassSection 생성 후 조회에 실패했습니다.');
    }

    return { course, classSection };
  }

  // 모든 수업 조회
  async getAllClassSections(): Promise<ClassSection[]> {
    return this.getAll<ClassSection>();
  }

  // 수업 검색
  async searchClassSections(params: ClassSectionSearchParams): Promise<ClassSection[]> {
    let query: admin.firestore.Query = this.db.collection(this.collectionName);

    // 수업명으로 검색
    if (params.name) {
      query = query.where('name', '>=', params.name)
                   .where('name', '<=', params.name + '\uf8ff');
    }

    // 강의 ID로 검색
    if (params.courseId) {
      query = query.where('courseId', '==', params.courseId);
    }

    // 교사 ID로 검색
    if (params.teacherId) {
      query = query.where('teacherId', '==', params.teacherId);
    }

    // 강의실 ID로 검색
    if (params.classroomId) {
      query = query.where('classroomId', '==', params.classroomId);
    }

    // 상태로 검색
    if (params.status) {
      query = query.where('status', '==', params.status);
    }

    return this.search<ClassSection>(query);
  }

  // 수업 통계 조회
  async getClassSectionStatistics(): Promise<{
    totalClassSections: number;
  }> {
    const classSections = await this.getAllClassSections();
    
    return {
      totalClassSections: classSections.length
    };
  }

  // ===== 시간표 관련 기능 =====

  // 시간표 블록 생성 (UI 표시용)
  private createScheduleBlock(classSection: ClassSection): ClassScheduleBlock[] {
    return classSection.schedule.map(schedule => ({
      id: classSection.id,
      title: classSection.name,
      subtitle: `${classSection.teacherId} - ${classSection.classroomId}`, // 실제로는 교사명과 강의실명을 가져와야 함
      dayOfWeek: schedule.dayOfWeek,
      startTime: schedule.startTime,
      endTime: schedule.endTime,
      color: classSection.color || '#e3f2fd', // 기본 색상
      order: classSection.displayOrder || 0
    }));
  }

  // 시간표 그리드 생성
  async createScheduleGrid(): Promise<ClassScheduleGrid> {
    const classSections = await this.getAllClassSections();
    
    // 모든 시간대 추출
    const timeSet = new Set<string>();
    classSections.forEach(section => {
      section.schedule.forEach(schedule => {
        timeSet.add(schedule.startTime);
        timeSet.add(schedule.endTime);
      });
    });
    
    // 시간대를 시간 순서로 정렬
    const timeSlots = Array.from(timeSet).sort((a, b) => {
      const timeA = new Date(`2000-01-01 ${a}`);
      const timeB = new Date(`2000-01-01 ${b}`);
      return timeA.getTime() - timeB.getTime();
    });
    
    // 요일 목록 - DayOfWeek 타입의 모든 값 사용
    const daysOfWeek: DayOfWeek[] = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];
    
    // 모든 시간표 블록 생성
    const blocks: ClassScheduleBlock[] = [];
    classSections.forEach(section => {
      blocks.push(...this.createScheduleBlock(section));
    });
    
    return {
      timeSlots,
      daysOfWeek,
      blocks
    };
  }

  // 특정 요일의 수업 조회
  async getClassSectionsByDay(dayOfWeek: DayOfWeek): Promise<ClassSection[]> {
    return this.search<ClassSection>(
      this.db.collection(this.collectionName)
        .where('schedule', 'array-contains', { dayOfWeek })
    );
  }

  // 특정 시간대의 수업 조회
  async getClassSectionsByTime(startTime: string, endTime: string): Promise<ClassSection[]> {
    const classSections = await this.getAllClassSections();
    
    return classSections.filter(section => 
      section.schedule.some(schedule => 
        schedule.startTime === startTime && schedule.endTime === endTime
      )
    );
  }

  // 시간표 검색
  async searchSchedule(params: ClassScheduleSearchParams): Promise<ClassSection[]> {
    let query: admin.firestore.Query = this.db.collection(this.collectionName);

    // 교사별 검색
    if (params.teacherId) {
      query = query.where('teacherId', '==', params.teacherId);
    }

    // 강의별 검색
    if (params.courseId) {
      query = query.where('courseId', '==', params.courseId);
    }

    // 요일별 검색
    if (params.dayOfWeek) {
      query = query.where('schedule', 'array-contains', { dayOfWeek: params.dayOfWeek });
    }

    // 상태별 검색
    if (params.status) {
      query = query.where('status', '==', params.status);
    }

    const results = await this.search<ClassSection>(query);

    // 시간 범위 검색 (클라이언트 사이드에서 필터링)
    if (params.timeRange) {
      return results.filter(section => 
        section.schedule.some(schedule => 
          schedule.startTime >= params.timeRange!.startTime && 
          schedule.endTime <= params.timeRange!.endTime
        )
      );
    }

    return results;
  }

  // 시간 충돌 검증
  async validateTimeConflict(
    teacherId: string, 
    classroomId: string, 
    dayOfWeek: DayOfWeek, 
    startTime: string, 
    endTime: string,
    excludeId?: string // 수정 시 제외할 수업 ID
  ): Promise<boolean> {
    const classSections = await this.searchSchedule({ 
      teacherId, 
      dayOfWeek, 
      status: 'active' 
    });

    // 제외할 수업이 있으면 필터링
    const filteredSections = excludeId 
      ? classSections.filter(section => section.id !== excludeId)
      : classSections;

    // 시간 충돌 검사
    for (const section of filteredSections) {
      for (const schedule of section.schedule) {
        if (schedule.dayOfWeek === dayOfWeek) {
          // 시간 겹침 검사
          const hasConflict = (
            (startTime < schedule.endTime && endTime > schedule.startTime) ||
            (schedule.startTime < endTime && schedule.endTime > startTime)
          );
          
          if (hasConflict) {
            return true; // 충돌 발생
          }
        }
      }
    }

    return false; // 충돌 없음
  }

  // 시간표 통계
  async getScheduleStatistics(): Promise<{
    totalClasses: number;
    classesByDay: Record<string, number>;
    classesByTime: Record<string, number>;
    mostBusyTime: string;
    leastBusyTime: string;
  }> {
    const classSections = await this.getAllClassSections();
    
    const classesByDay: Record<string, number> = {};
    const classesByTime: Record<string, number> = {};
    
    classSections.forEach(section => {
      section.schedule.forEach(schedule => {
        // 요일별 통계
        classesByDay[schedule.dayOfWeek] = (classesByDay[schedule.dayOfWeek] || 0) + 1;
        
        // 시간대별 통계
        const timeKey = `${schedule.startTime}-${schedule.endTime}`;
        classesByTime[timeKey] = (classesByTime[timeKey] || 0) + 1;
      });
    });
    
    // 가장 바쁜 시간대와 가장 한가한 시간대 찾기
    let mostBusyTime = '';
    let leastBusyTime = '';
    let maxCount = 0;
    let minCount = Infinity;
    
    Object.entries(classesByTime).forEach(([time, count]) => {
      if (count > maxCount) {
        maxCount = count;
        mostBusyTime = time;
      }
      if (count < minCount) {
        minCount = count;
        leastBusyTime = time;
      }
    });
    
    return {
      totalClasses: classSections.length,
      classesByDay,
      classesByTime,
      mostBusyTime,
      leastBusyTime
    };
  }

}
