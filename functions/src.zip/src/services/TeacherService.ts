import * as admin from 'firebase-admin';
import { BaseService } from './BaseService';
import type { 
  Teacher, 
  CreateTeacherRequest, 
  UpdateTeacherRequest, 
  TeacherSearchParams
} from '@shared/types';

export class TeacherService extends BaseService {
  constructor() {
    super('teachers');
  }

  // 강사 생성
  async createTeacher(data: CreateTeacherRequest): Promise<string> {
    const teacherData: Omit<Teacher, 'id'> = {
      ...data,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    };

    return this.create(teacherData);
  }

  // 강사 조회 (ID로)
  async getTeacherById(id: string): Promise<Teacher | null> {
    return this.getById<Teacher>(id);
  }

  // 강사 수정
  async updateTeacher(id: string, data: UpdateTeacherRequest): Promise<void> {
    const updateData = {
      ...data,
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    };

    await this.update(id, updateData);
  }

  // 강사 삭제
  async deleteTeacher(id: string): Promise<void> {
    await this.delete(id);
  }

  // 모든 강사 조회
  async getAllTeachers(): Promise<Teacher[]> {
    return this.getAll<Teacher>();
  }

  // 강사 검색
  async searchTeachers(params: TeacherSearchParams): Promise<Teacher[]> {
    let query: admin.firestore.Query = this.db.collection(this.collectionName);

    // 이름으로 검색
    if (params.name) {
      query = query.where('name', '>=', params.name)
                   .where('name', '<=', params.name + '\uf8ff');
    }

    return this.search<Teacher>(query);
  }

  // 강사 통계 조회
  async getTeacherStatistics(): Promise<{
    totalTeachers: number;
  }> {
    const teachers = await this.getAllTeachers();
    
    return {
      totalTeachers: teachers.length
    };
  }

  // 강사 정보 검증
  async validateTeacherData(teacherData: Partial<Teacher>): Promise<{
    isValid: boolean;
    issues: string[];
  }> {
    const issues: string[] = [];

    // 필수 필드 검증
    if (!teacherData.name || teacherData.name.trim().length === 0) {
      issues.push('강사 이름은 필수입니다.');
    }

    // 이메일 형식 검증 (선택사항이지만 값이 있으면 유효해야 함)
    if (teacherData.email && teacherData.email.trim().length > 0) {
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(teacherData.email)) {
        issues.push('유효한 이메일 형식이 아닙니다.');
      }
    }

    return {
      isValid: issues.length === 0,
      issues
    };
  }
}
